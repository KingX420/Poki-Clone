try {
    let e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
        s = (new e.Error).stack;
    s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "854d2f0f-0d5b-461f-bb40-98ce54f8b370", e._sentryDebugIdIdentifier = "sentry-dbid-854d2f0f-0d5b-461f-bb40-98ce54f8b370")
} catch (e) {}("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
    id: "75bcf2398d3fb2a92281989653952fcadc61081a"
};
(self.__LOADABLE_LOADED_CHUNKS__ = self.__LOADABLE_LOADED_CHUNKS__ || []).push([
    [637], {
        10637: (e, s, i) => {
            i.r(s), i.d(s, {
                default: () => A
            });
            var t = i(17402),
                n = i(57225),
                o = i(78737),
                r = i(34164),
                l = i(73421),
                a = i(40890),
                d = "cmwhPovN5VyaNFLxpR8k",
                c = i(95901);
            const p = [0, 94, 204, 314],
                u = {
                    home: {
                        mobile: {
                            "most-played": {
                                0: {
                                    size: 2
                                },
                                1: {
                                    size: 2,
                                    responsive: [
                                        [3, 8]
                                    ]
                                },
                                2: {
                                    size: 2,
                                    responsive: [
                                        [3, 5],
                                        [2, 6]
                                    ]
                                },
                                3: {
                                    size: 2,
                                    responsive: [
                                        [3, 6],
                                        [2, 8]
                                    ]
                                },
                                4: {
                                    size: 1,
                                    responsive: [
                                        [2, 5],
                                        [3, 6],
                                        [2, 8]
                                    ]
                                },
                                5: {
                                    size: 1,
                                    responsive: [
                                        [2, 5],
                                        [3, 6]
                                    ]
                                },
                                6: {
                                    size: 1,
                                    responsive: [
                                        [3, 5],
                                        [2, 6],
                                        [3, 8]
                                    ]
                                },
                                7: {
                                    size: 1,
                                    responsive: [
                                        [2, 8]
                                    ]
                                },
                                8: {
                                    size: 1,
                                    responsive: [
                                        [2, 8]
                                    ]
                                },
                                9: {
                                    size: 1,
                                    responsive: [
                                        [2, 8]
                                    ]
                                },
                                10: {
                                    size: 1,
                                    responsive: [
                                        [2, 8]
                                    ]
                                }
                            }
                        },
                        desktop: {
                            "most-played": {
                                0: {
                                    size: 3
                                },
                                1: {
                                    size: 2,
                                    responsive: [
                                        [3, 9]
                                    ]
                                },
                                2: {
                                    size: 2,
                                    responsive: [
                                        [3, 14]
                                    ]
                                },
                                3: {
                                    size: 2,
                                    responsive: [
                                        [3, 17]
                                    ]
                                },
                                4: {
                                    size: 2
                                },
                                5: {
                                    size: 3,
                                    responsive: [
                                        [2, 9]
                                    ]
                                },
                                6: {
                                    size: 2
                                },
                                7: {
                                    size: 2
                                },
                                8: {
                                    size: 3,
                                    responsive: [
                                        [2, 9]
                                    ]
                                },
                                9: {
                                    size: 2
                                },
                                10: {
                                    size: 2,
                                    responsive: [
                                        [3, 9],
                                        [2, 12]
                                    ]
                                },
                                11: {
                                    size: 3,
                                    responsive: [
                                        [2, 11],
                                        [3, 14],
                                        [2, 17]
                                    ]
                                },
                                12: {
                                    size: 3,
                                    responsive: [
                                        [2, 11]
                                    ]
                                },
                                13: {
                                    size: 2,
                                    responsive: [
                                        [3, 11],
                                        [2, 12]
                                    ]
                                },
                                14: {
                                    size: 2
                                },
                                15: {
                                    size: 2,
                                    responsive: [
                                        [3, 14],
                                        [2, 17]
                                    ]
                                },
                                16: {
                                    size: 1,
                                    responsive: [
                                        [2, 1],
                                        [1, 12],
                                        [2, 14]
                                    ]
                                },
                                17: {
                                    size: 1,
                                    responsive: [
                                        [2, 1],
                                        [1, 12],
                                        [2, 17]
                                    ]
                                },
                                18: {
                                    size: 1,
                                    responsive: [
                                        [2, 1],
                                        [1, 11],
                                        [2, 17]
                                    ]
                                },
                                19: {
                                    size: 1,
                                    responsive: [
                                        [2, 1],
                                        [1, 9],
                                        [2, 17]
                                    ]
                                },
                                20: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                21: {
                                    size: 1,
                                    responsive: [
                                        [3, 17]
                                    ]
                                },
                                22: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                23: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                24: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                25: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                }
                            }
                        }
                    },
                    category: {
                        mobile: {
                            "basic-game": {
                                0: {
                                    size: 2
                                }
                            }
                        },
                        desktop: {
                            "basic-game": {
                                0: {
                                    size: 2
                                },
                                1: {
                                    size: 2
                                },
                                2: {
                                    size: 2
                                },
                                3: {
                                    size: 2
                                },
                                4: {
                                    size: 2
                                },
                                5: {
                                    size: 1,
                                    responsive: [
                                        [2, 9]
                                    ]
                                },
                                6: {
                                    size: 1,
                                    responsive: [
                                        [2, 9]
                                    ]
                                },
                                7: {
                                    size: 1,
                                    responsive: [
                                        [2, 11]
                                    ]
                                },
                                8: {
                                    size: 1,
                                    responsive: [
                                        [2, 11]
                                    ]
                                },
                                9: {
                                    size: 1,
                                    responsive: [
                                        [2, 12]
                                    ]
                                },
                                10: {
                                    size: 1,
                                    responsive: [
                                        [2, 14]
                                    ]
                                },
                                11: {
                                    size: 1,
                                    responsive: [
                                        [2, 14]
                                    ]
                                },
                                12: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                13: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                },
                                14: {
                                    size: 1,
                                    responsive: [
                                        [2, 17]
                                    ]
                                }
                            }
                        }
                    },
                    game: {
                        desktop: {
                            related: {
                                0: {
                                    size: 1,
                                    responsive: [
                                        [2, 12]
                                    ]
                                },
                                1: {
                                    size: 1,
                                    responsive: [
                                        [2, 12]
                                    ]
                                }
                            },
                            "game-not-available": {
                                0: {
                                    size: 2
                                },
                                1: {
                                    size: 2
                                }
                            }
                        }
                    },
                    search: {
                        desktop: {
                            "good-search-result": 2
                        },
                        mobile: {
                            "good-search-result": {
                                0: {
                                    size: 2
                                }
                            }
                        }
                    }
                },
                m = ({
                    list: e,
                    idx: s,
                    componentKey: i,
                    isMobile: t
                }) => {
                    const n = s || 0,
                        o = ((u[i] || {})[t ? "mobile" : "desktop"] || {})[e] || {},
                        r = "number" == typeof o ? o : o[n] ? .size ? ? 1,
                        l = o[n] ? .responsive ? ? [];
                    return {
                        size: r,
                        responsive: l,
                        isMapped: r > 1 || l.length > 0
                    }
                },
                h = ({
                    list: e,
                    idx: s,
                    image: i,
                    alt: t = "",
                    lazy: n = !0,
                    componentKey: o = "",
                    isMobile: r = !1
                }) => {
                    const {
                        srcset: u = [],
                        sizes: h = [],
                        src: v,
                        width: y,
                        defaultWidth: z = p[1]
                    } = (({
                        list: e,
                        idx: s,
                        image: i,
                        componentKey: t,
                        isMobile: n
                    }) => {
                        const {
                            size: o,
                            responsive: r
                        } = m({
                            list: e,
                            idx: s,
                            componentKey: t,
                            isMobile: n
                        }), d = [(0, a.pN)({
                            width: p[o],
                            image: i
                        }), (0, a.pN)({
                            width: 2 * p[o],
                            image: i
                        })];
                        if (r) {
                            const e = r.length,
                                s = [],
                                t = [],
                                n = [],
                                [c, u] = e > 2 ? r[r.length - 1] : [null, null];
                            let m = !1;
                            for (let o = 0; o < e && !(o + 1 >= e && m); o++) {
                                const e = r[o],
                                    d = e[0],
                                    h = e[1];
                                s.push(`${(0,a.pN)({width:p[d],image:i})} 1x, ${(0,a.pN)({width:2*p[d],image:i})} 2x`);
                                const v = r[o + 1];
                                let y = "";
                                if (v) {
                                    const e = v[1];
                                    y = ` and ${(0,l.mK)(e,"max")}`
                                }
                                let z = "";
                                d === c && (m = !0, z = `, ${(0,l.mK)(u,"min")}`), t.push(`${(0,l.mK)(h)}${y}${z}`), n.push(p[d])
                            }
                            return {
                                src: d,
                                srcset: s,
                                sizes: t,
                                width: n,
                                defaultWidth: p[o]
                            }
                        }
                        return {
                            src: d,
                            defaultWidth: p[o]
                        }
                    })({
                        list: e,
                        idx: s,
                        image: i,
                        componentKey: o,
                        isMobile: r
                    }), g = n ? "lazy" : "eager", b = `${o}-${e}-${v}-${z}-${y}`;
                    if (u.length && h.length) {
                        const e = [],
                            {
                                length: s
                            } = u,
                            i = `picture-${b}`;
                        for (let t = 0; t < s; t++) {
                            const s = `${i}-source-${y[t]}-${t}`,
                                n = (0, c.Y)("source", {
                                    srcSet: u[t],
                                    media: h[t],
                                    width: y[t],
                                    height: y[t]
                                }, s);
                            e.push(n)
                        }
                        return (0, c.FD)("picture", {
                            className: "xsoR0rbt8iM8_hOhWnUk",
                            children: [e, (0, c.Y)("img", {
                                className: d,
                                src: v[0],
                                alt: t,
                                srcSet: `${v[0]} 1x, ${v[1]} 2x`,
                                loading: g,
                                decoding: "async",
                                width: z,
                                height: z
                            })]
                        }, i)
                    }
                    const f = `img-${b}`;
                    return (0, c.Y)("img", {
                        className: d,
                        src: v[0],
                        srcSet: `${v[0]} 1x, ${v[1]} 2x`,
                        alt: t,
                        loading: g,
                        decoding: "async",
                        width: z,
                        height: z
                    }, f)
                };
            var v = i(56832),
                y = i(42891),
                z = i(18272);
            var g = i(51508);
            const b = (0, n.Ay)({
                    resolved: {},
                    chunkName: () => "app-components-Shimmer-tsx",
                    isReady(e) {
                        const s = this.resolve(e);
                        return !0 === this.resolved[s] && !!i.m[s]
                    },
                    importAsync: () => i.e(8935).then(i.bind(i, 98250)),
                    requireAsync(e) {
                        const s = this.resolve(e);
                        return this.resolved[s] = !1, this.importAsync(e).then((e => (this.resolved[s] = !0, e)))
                    },
                    requireSync(e) {
                        const s = this.resolve(e);
                        return i(s)
                    },
                    resolve: () => 98250
                }),
                f = (0, n.Ay)({
                    resolved: {},
                    chunkName: () => "app-components-TileLabel-tsx",
                    isReady(e) {
                        const s = this.resolve(e);
                        return !0 === this.resolved[s] && !!i.m[s]
                    },
                    importAsync: () => i.e(9008).then(i.bind(i, 44237)),
                    requireAsync(e) {
                        const s = this.resolve(e);
                        return this.resolved[s] = !1, this.importAsync(e).then((e => (this.resolved[s] = !0, e)))
                    },
                    requireSync(e) {
                        const s = this.resolve(e);
                        return i(s)
                    },
                    resolve: () => 44237
                }),
                w = (0, n.Ay)({
                    resolved: {},
                    chunkName: () => "app-components-TileVideo-tsx",
                    isReady(e) {
                        const s = this.resolve(e);
                        return !0 === this.resolved[s] && !!i.m[s]
                    },
                    importAsync: () => i.e(5139).then(i.bind(i, 57190)),
                    requireAsync(e) {
                        const s = this.resolve(e);
                        return this.resolved[s] = !1, this.importAsync(e).then((e => (this.resolved[s] = !0, e)))
                    },
                    requireSync(e) {
                        const s = this.resolve(e);
                        return i(s)
                    },
                    resolve: () => 57190
                });
            const x = {
                    width: 628,
                    q: 6,
                    scq: 3,
                    blur: 12
                },
                _ = {
                    width: 408,
                    q: 10,
                    scq: 5,
                    blur: 5
                };

            function A({
                className: e,
                data: s = {
                    id: 0,
                    image: {
                        path: ""
                    },
                    isNew: !1,
                    slug: "",
                    title: "",
                    url: ""
                },
                alwaysShowTitle: i,
                list: n,
                idx: l,
                componentKey: d,
                label: p,
                lazy: u = !0,
                isMobile: A = !1,
                onClick: M,
                panelSection: N,
                trackingIndex: T
            }) {
                const $ = (0, t.useRef)(null),
                    [k, S] = (0, t.useState)(!1),
                    K = (0, o.d4)(y.Rd),
                    {
                        isMapped: q
                    } = m({
                        list: n,
                        idx: l,
                        componentKey: d,
                        isMobile: A
                    }),
                    D = s ? .imageAlt && K >= .5,
                    E = (0, t.useMemo)((() => function({
                        useAltImg: e = !1,
                        data: s,
                        lazy: i,
                        isMobile: t,
                        list: n,
                        idx: o,
                        componentKey: r,
                        isMapped: l
                    }) {
                        const {
                            image: a,
                            imageAlt: d
                        } = s, c = !l && i;
                        return h({
                            list: n,
                            idx: o,
                            image: e ? d : a,
                            alt: s.title,
                            lazy: c,
                            componentKey: r,
                            isMobile: t
                        })
                    }({
                        useAltImg: D,
                        data: s,
                        lazy: u,
                        isMobile: A,
                        list: n,
                        idx: l,
                        componentKey: d,
                        isMapped: q
                    })), [D]),
                    R = (0, t.useMemo)((() => !A && s ? .animatedThumbnail), [A, s]),
                    I = (0, t.useMemo)((() => {
                        if (!R) return null;
                        const e = s ? .animatedThumbnail;
                        return (0, c.Y)(w, {
                            videoUrl: e,
                            videoSize: "3x3"
                        })
                    }), [R, s]),
                    L = (0, t.useMemo)((() => function(e, s) {
                        const {
                            width: i,
                            q: t,
                            scq: n,
                            blur: o
                        } = s ? _ : x;
                        return (0, a.pN)({
                            width: i,
                            image: {
                                path: e
                            },
                            quality: t,
                            slowConnectionQuality: n,
                            blur: o
                        })
                    }(s.image.path, A)), [s.image.path, A]),
                    C = (0, t.useMemo)((() => function({
                        label: e,
                        isNew: s
                    }) {
                        return e || (s ? "new" : null)
                    }({
                        label: p,
                        isNew: s.isNew
                    })), [p, s.isNew]),
                    Y = 29160 === s.id,
                    F = (0, t.useCallback)((() => {
                        S(!0)
                    }), []),
                    O = (0, t.useCallback)((() => {
                        S(!1)
                    }), []),
                    U = (0, t.useCallback)((e => {
                        e.preventDefault(), M && M();
                        const {
                            pageY: i
                        } = e, t = T || l;
                        (0, v.D)({
                            id: s.id,
                            image: D ? "b" : "a",
                            path: s.url,
                            panelSection: N,
                            index: t,
                            type: "game",
                            list: n,
                            y: i
                        }), (0, z.A)().push(s.url)
                    }), [M, s.id, D, s.url, N, l, T, n]),
                    H = (0, t.useMemo)((() => (0, r.$)("summaryTile", g.summaryTile, g.summaryTile_fixedAspectRatio, i && g.summaryTile_showTitle, q && g.summaryTile_container, e)), [i, q, e]),
                    Z = (0, t.useMemo)((() => u ? {} : {
                        backgroundImage: `url(${L})`
                    }), [u, L]);
                return (0, c.FD)("a", {
                    className: H,
                    ref: $,
                    href: s.url,
                    onClick: U,
                    onMouseEnter: R ? F : void 0,
                    onMouseLeave: R ? O : void 0,
                    style: Z,
                    children: [!Y && E, (0, c.Y)("span", {
                        className: (0, r.$)(g.summaryTile__title, "global-cq-title"),
                        children: s.title
                    }), Y && E && (0, c.Y)(b, {
                        sourcePicture: E,
                        destinationPicture: h({
                            list: n,
                            idx: l,
                            image: { ...s.image,
                                path: "7a35d4a468a820f1dc72b9ad22e9aeec.jpg"
                            },
                            alt: s.title,
                            lazy: !1,
                            componentKey: d,
                            isMobile: A
                        })
                    }), R && k && I, C && (0, c.Y)(f, {
                        label: C
                    })]
                })
            }
        },
        51508: (e, s, i) => {
            i.r(s), i.d(s, {
                summaryTile: () => t,
                summaryTile__img: () => n,
                summaryTile__title: () => o,
                summaryTile_container: () => r,
                summaryTile_fixedAspectRatio: () => l,
                summaryTile_showTitle: () => a
            });
            var t = "I_N3HLb877sRrr2UZJfZ",
                n = "D3Z8q7OZ8mzEGVwJuEq0",
                o = "MHaP7Us7V6KqGxb8muHM",
                r = "XxuAeockFFccwluXvlEw",
                l = "xCChko93rfK8hvsE5sNR",
                a = "fpevFTAiloXLA6hldCmO"
        },
        56832: (e, s, i) => {
            i.d(s, {
                D: () => o
            });
            var t = i(46493),
                n = i(88421);

            function o(e) {
                const s = window.store.getState(),
                    i = e ? .panelSection ? .length > 0,
                    o = i ? {
                        searchExpanded: i,
                        terms: (0, n.Z1)(s),
                        searchSessionId: (0, n.Ie)(s)
                    } : {},
                    r = { ...e,
                        ...o
                    };
                (0, t.F)({
                    category: "tile",
                    action: "click",
                    data: r
                })
            }
        }
    }
]);
//# sourceMappingURL=client~637~3da57cb81b1b9b56c88a.js.map